#include <stdio.h>
#include <stdlib.h>

struct Employee {
    int* ratings;
    int totalScore;
};

void getRatings(int** ratings, int employeeCount, int periodCount);
void showRatings(int** ratings, int employeeCount, int periodCount);
int bestEmployee(int** ratings, int employeeCount, int periodCount);
int bestPeriod(int** ratings, int employeeCount, int periodCount);
int worstEmployee(int** ratings, int employeeCount, int periodCount);

int main() {
    int employeeCount, periodCount;

    printf("Enter the number of employees: ");
    scanf("%d", &employeeCount);

    printf("Enter the number of evaluation periods: ");
    scanf("%d", &periodCount);

    int** ratings = malloc(sizeof(int*) * employeeCount);
    for (int i = 0; i < employeeCount; i++) {
        ratings[i] = malloc(sizeof(int) * periodCount);
    }

    getRatings(ratings, employeeCount, periodCount);
    showRatings(ratings, employeeCount, periodCount);

    printf("\nEmployee of the Year: Employee %d\n", 
           bestEmployee(ratings, employeeCount, periodCount));

    printf("\nBest Evaluation Period: Period %d\n", 
           bestPeriod(ratings, employeeCount, periodCount));

    printf("\nWorst Performing Employee: Employee %d\n", 
           worstEmployee(ratings, employeeCount, periodCount));
      	int i;
    for (i = 0; i < employeeCount; i++) {
        free(ratings[i]);
    }
    free(ratings);

    return 0;
}

void getRatings(int** ratings, int employeeCount, int periodCount) {
    int score,emp;
    for ( emp = 0; emp < employeeCount; emp++) {
        for (int period = 0; period < periodCount; period++) {
            printf("Enter the rating for Employee %d in Period %d (1-10): ", 
                   emp + 1, period + 1);
            scanf("%d", &score);
            ratings[emp][period] = (score >= 1 && score <= 10) ? score : 0;
        }
        printf("\n");
    }
}

void showRatings(int** ratings, int employeeCount, int periodCount) {
	int emp,period;
    for ( emp = 0; emp < employeeCount; emp++) {
        printf("Employee %d:", emp + 1);
        for ( period = 0; period < periodCount; period++) {
            printf("\t%d", ratings[emp][period]);
        }
        printf("\n");
    }
}

int bestEmployee(int** ratings, int employeeCount, int periodCount) {
    double average, highestAverage = 0;
    int topEmployee = -1;
        int emp,period;
    for (emp = 0; emp < employeeCount; emp++) {
        average = 0;
        for ( period = 0; period < periodCount; period++) {
            average += ratings[emp][period];
        }
        if (average > highestAverage) {
            highestAverage = average;
            topEmployee = emp;
        }
    }
    return topEmployee + 1;
}

int bestPeriod(int** ratings, int employeeCount, int periodCount) {
    double average, highestAverage = 0;
    int topPeriod = -1;
    int period,emp;
    for (period = 0; period < periodCount; period++) {
        average = 0;
        for ( emp = 0; emp < employeeCount; emp++) {
            average += ratings[emp][period];
        }
        if (average > highestAverage) {
            highestAverage = average;
            topPeriod = period;
        }
    }
    return topPeriod + 1;
}

int worstEmployee(int** ratings, int employeeCount, int periodCount) {
    double average, lowestAverage = 100;
    int bottomEmployee = -1;
     int emp,period;
    for ( emp = 0; emp < employeeCount; emp++) {
        average = 0;
        for ( period = 0; period < periodCount; period++) {
            average += ratings[emp][period];
        }
        if (average < lowestAverage) {
            lowestAverage = average;
            bottomEmployee = emp;
        }
    }
    return bottomEmployee + 1;
}

