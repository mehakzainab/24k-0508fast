#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

struct Equipment {
    bool operational_status;
    int fuel_level;
    int activity_schedule;
};

struct Sensor {
    int soil_nutrients;
    int pH_level;
    bool pest_activity_detected;
};

struct GPS {
    double latitude;
    double longitude;
};

struct SoilMetrics {
    char texture[10];
    int density;
};

struct WeatherForecast {
    int temperature;
    int rainfall_level;
    char wind_patterns[20];
};

struct Crop {
    char type[10];
    int growth_stage;
    double yield;
    struct WeatherForecast* weather;
};

struct Field {
    struct GPS location;
    struct SoilMetrics soil;
    int moisture_level;
    struct Crop* crops;
    int crop_count;
    struct Sensor sensors;
};

struct RegionalHub {
    struct Field* fields;
    int field_count;
    int predicted_yield;
    int resource_distribution;
    char emergency_response_plan[100];
};

struct WeatherForecast* create_weather_forecast(int temp, int rainfall, const char* wind_patterns);
struct Crop* create_crops(int count);
struct Field create_field();
struct RegionalHub create_regional_hub();
void display_regional_hub(struct RegionalHub hub);
void free_regional_hub(struct RegionalHub* hub);

int main() {
    struct RegionalHub hub = create_regional_hub();

    display_regional_hub(hub);

    free_regional_hub(&hub);

    return 0;
}

struct WeatherForecast* create_weather_forecast(int temp, int rainfall, const char* wind_patterns) {
    struct WeatherForecast* wf = malloc(sizeof(struct WeatherForecast));
    wf->temperature = temp;
    wf->rainfall_level = rainfall;
    strcpy(wf->wind_patterns, wind_patterns);
    return wf;
}

struct Crop* create_crops(int count) {
	int i;
    struct Crop* crops = malloc(count * sizeof(struct Crop));
    for ( i = 0; i < count; i++) {
        printf("Enter details for crop %d:\n", i + 1);
        printf("Crop type: ");
        scanf("%s", crops[i].type);
        printf("Growth stage: ");
        scanf("%d", &crops[i].growth_stage);
        printf("Crop yield: ");
        scanf("%lf", &crops[i].yield);

        crops[i].weather = create_weather_forecast(25, 50, "Moderate Winds");
    }
    return crops;
}

struct Field create_field() {
    struct Field f;

    printf("Enter GPS coordinates (latitude longitude): ");
    scanf("%lf %lf", &f.location.latitude, &f.location.longitude);
    printf("Enter soil texture: ");
    scanf("%s", f.soil.texture);
    printf("Enter soil density: ");
    scanf("%d", &f.soil.density);

    printf("Enter moisture level: ");
    scanf("%d", &f.moisture_level);
    printf("Enter number of crops: ");
    scanf("%d", &f.crop_count);
    f.crops = create_crops(f.crop_count);
    printf("Enter soil nutrients level: ");
    scanf("%d", &f.sensors.soil_nutrients);
    printf("Enter soil pH level: ");
    scanf("%d", &f.sensors.pH_level);
    printf("Is pest activity detected? (1 for Yes, 0 for No): ");
    scanf("%d", (int*)&f.sensors.pest_activity_detected);

    return f;
}

struct RegionalHub create_regional_hub() {
    struct RegionalHub hub;
    int i;

    printf("Enter number of fields in the hub: ");
    scanf("%d", &hub.field_count);
    hub.fields = (struct Field*)malloc(hub.field_count * sizeof(struct Field));

    for ( i = 0; i < hub.field_count; i++) {
        printf("Initializing field %d:\n", i + 1);
        hub.fields[i] = create_field();
    }

    printf("Enter yield prediction: ");
    scanf("%d", &hub.predicted_yield);
    printf("Enter resource distribution: ");
    scanf("%d", &hub.resource_distribution);
    printf("Enter emergency response plan: ");
    getchar();
    fgets(hub.emergency_response_plan, sizeof(hub.emergency_response_plan), stdin);

    return hub;
}

void display_regional_hub(struct RegionalHub hub) {
    printf("\nRegional Hub Overview\n");
    printf("Number of fields: %d\n", hub.field_count);
    printf("Predicted Yield: %d\n", hub.predicted_yield);
    printf("Resource Distribution: %d\n", hub.resource_distribution);
    printf("Emergency Response Plan: %s\n", hub.emergency_response_plan);
     	int i,j;
    for ( i = 0; i < hub.field_count; i++) {
        printf("\nField %d Details:\n", i + 1);
        printf("  GPS Coordinates: (%.2f, %.2f)\n", hub.fields[i].location.latitude, hub.fields[i].location.longitude);
        printf("  Soil Texture: %s\n", hub.fields[i].soil.texture);
        printf("  Soil Density: %d\n", hub.fields[i].soil.density);
        printf("  Moisture Level: %d\n", hub.fields[i].moisture_level);
        printf("  Sensor Data - Nutrients: %d, pH: %d, Pest Activity: %s\n",
            hub.fields[i].sensors.soil_nutrients,
             hub.fields[i].sensors.pH_level,
           hub.fields[i].sensors.pest_activity_detected ? "Yes" : "No");

        for ( j = 0; j < hub.fields[i].crop_count; j++) {
            printf("\tCrop %d:\n", j + 1);
            printf("\t\tType: %s, Growth Stage: %d, Yield: %.2f\n",
                   hub.fields[i].crops[j].type,
                   hub.fields[i].crops[j].growth_stage,
                   hub.fields[i].crops[j].yield);
            printf("\t\tWeather - Temp: %d, Rainfall: %d, Winds: %s\n",
                   hub.fields[i].crops[j].weather->temperature,
                   hub.fields[i].crops[j].weather->rainfall_level,
                   hub.fields[i].crops[j].weather->wind_patterns);
        }
    }
}

void free_regional_hub(struct RegionalHub* hub) {
		int i,j;
    for ( i = 0; i < hub->field_count; i++) {
        for ( j = 0; j < hub->fields[i].crop_count; j++) {
            free(hub->fields[i].crops[j].weather);
        }
        free(hub->fields[i].crops);
    }
    free(hub->fields);
}

