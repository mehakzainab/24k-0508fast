#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int emailLength = 0;

int isValidEmail(char* email);

int main() {
    char tempEmail[128];
    printf("Enter Email: ");
    scanf("%127s", tempEmail);
     	int i;
    for (i = 0; tempEmail[i] != '\0'; i++) {
        emailLength++;
    }

    char* email = malloc(sizeof(char) * (emailLength + 1));
    if (email == NULL) {
        return 1;
    }

    strcpy(email, tempEmail);

    if (isValidEmail(email)) {
        printf("Valid Email\n");
    } else {
        printf("Invalid Email\n");
    }

    free(email);
    return 0;
}

int isValidEmail(char* email) {
    if (emailLength > 0) {
        int hasAtSymbol = 0, hasDotSymbol = 0;
        int atIndex = -1, dotIndex = -1;
       	int i;
        for (i = 0; i < emailLength; i++) {
            if (email[i] == '@') {
                if (hasAtSymbol == 0) {
                    hasAtSymbol = 1;
                    atIndex = i;
                } else {
                    return 0;
                }
            }
            if (email[i] == '.') {
                hasDotSymbol = 1;
                dotIndex = i;
            }
        }

        if (hasAtSymbol && hasDotSymbol && atIndex < dotIndex) {
            return 1;
        }
        return 0;
    }
    return 0;
}

