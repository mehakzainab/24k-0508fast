#include <stdio.h>
#include <string.h>

struct Player {
    int ballScores[12];
    char name[20];
    int totalScore;
};


struct Player player1[1];
struct Player player2[1];


int playGame(struct Player*);
int validateScore(int);
int determineWinner(struct Player*, struct Player*);
void displayScoreboard(struct Player*, struct Player*);

int main() {
   
    printf("Enter Player 1 name: ");
    fgets(player1->name, sizeof(player1->name), stdin);
    player1->name[strcspn(player1->name, "\n")] = '\0';

    printf("Enter Player 2 name: ");
    fgets(player2->name, sizeof(player2->name), stdin);
    player2->name[strcspn(player2->name, "\n")] = '\0';

    playGame(player1);
    playGame(player2);

  
    determineWinner(player1, player2);

    
    displayScoreboard(player1, player2);

    printf("\n\t\t\t\tGAME ENDED\t\t\t\t\n");
    return 0;
}


int playGame(struct Player* player) {
		int i;
    for (i = 0; i < 12; i++) {
        printf("Enter %s's score for ball %d: ", player->name, i + 1);
        scanf("%d", &player->ballScores[i]);
        player->ballScores[i] = validateScore(player->ballScores[i]);
        player->totalScore += player->ballScores[i];
    }

    printf("\n\n%s's turn has ended.\n\n", player->name);
    printf("Scores: ");
    for (i = 0; i < 12; i++) {
        printf("%d ", player->ballScores[i]);
    }
    printf("\n\n");
    return 0;
}


int validateScore(int score) {
    return (score >= 0 && score <= 6) ? score : 0;
}

int determineWinner(struct Player* player1, struct Player* player2) {
    if (player1->totalScore > player2->totalScore) {
        printf("\t\t\t\t%s Wins!\n\n", player1->name);
    } else {
        printf("\t\t\t\t%s Wins!\n\n", player2->name);
    }
    return 0;
}


void displayScoreboard(struct Player* player1, struct Player* player2) {
    int avgScore1 = 0, avgScore2 = 0;
	int i;
    for ( i = 0; i < 12; i++) {
        avgScore1 += player1->ballScores[i];
        avgScore2 += player2->ballScores[i];
    }
    avgScore1 /= 12;
    avgScore2 /= 12;

    printf("\t\tP1      P2\n");
    for (i = 0; i < 12; i++) {
        printf("Ball %d Score: \t%d       %d\n", i + 1,
               player1->ballScores[i], player2->ballScores[i]);
    }

    printf("Average Score:  %d       %d\n", avgScore1, avgScore2);
    printf("Total Score:    %d       %d\n", player1->totalScore, player2->totalScore);
}

