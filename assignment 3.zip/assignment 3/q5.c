#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Pet {
    char** supplies; 
    char* name;     
    int supplyCount; 
};

struct Pet* petInventory = NULL; 
int totalSpecies = 0;            

void initializeInventory();
void addSupplies();
void updateSupply();
void removeSpecies();
void showInventory();

int main() {
    int choice;

    while (1) {
        printf("\nPet Shop Inventory System\n");
        printf("1. Initialize Inventory\n"
               "2. Add Supplies\n"
               "3. Update Supply\n"
               "4. Remove Species\n"
               "5. Show Inventory\n"
               "6. Exit\n"
               "Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                initializeInventory();
                break;
            case 2:
                addSupplies();
                break;
            case 3:
                updateSupply();
                break;
            case 4:
                removeSpecies();
                break;
            case 5:
                showInventory();
                break;
            case 6:
                printf("\tGoodbye!\n");
                return 0;
            default:
                printf("Invalid choice. Try again.\n");
        }
    }
    return 0;
}

void initializeInventory() {
	int i;
    printf("Enter the number of species: ");
    scanf("%d", &totalSpecies);

    petInventory = malloc(totalSpecies * sizeof(struct Pet));
    for ( i = 0; i < totalSpecies; i++) {
        petInventory[i].name = malloc(50 * sizeof(char)); 
        petInventory[i].supplies = NULL;                
        petInventory[i].supplyCount = 0;                
        printf("Enter the name of species %d: ", i + 1);
        scanf("%s", petInventory[i].name);
    }
    printf("Inventory initialized with %d species.\n", totalSpecies);
}

void addSupplies() {
	int i,j;
    int numSupplies;
    for (i = 0; i < totalSpecies; i++) {
        printf("Enter the number of supplies for species %s: ", petInventory[i].name);
        scanf("%d", &numSupplies);

        petInventory[i].supplies = malloc(numSupplies * sizeof(char*)); 
        petInventory[i].supplyCount = numSupplies;                      

        printf("Enter supplies:\n");
        for (j = 0; j < numSupplies; j++) {
            petInventory[i].supplies[j] = malloc(50 * sizeof(char)); 
            scanf("%s", petInventory[i].supplies[j]);
        }
    }
    printf("Supplies added.\n");
}

void updateSupply() {
    int speciesIndex, supplyIndex;
    char newSupply[50];

    printf("Enter species index (1 to %d): ", totalSpecies);
    scanf("%d", &speciesIndex);
    speciesIndex--;

    if (speciesIndex < 0 || speciesIndex >= totalSpecies) {
        printf("Invalid species index.\n");
        return;
    }

    printf("Enter supply index (1 to %d): ", petInventory[speciesIndex].supplyCount);
    scanf("%d", &supplyIndex);
    supplyIndex--;

    if (supplyIndex < 0 || supplyIndex >= petInventory[speciesIndex].supplyCount) {
        printf("Invalid supply index.\n");
        return;
    }

    printf("Enter the new supply name: ");
    scanf("%s", newSupply);

    strcpy(petInventory[speciesIndex].supplies[supplyIndex], newSupply);
    printf("Supply updated.\n");
}

void removeSpecies() {
	int i;
    int speciesIndex;
    printf("Enter species index to remove (1 to %d): ", totalSpecies);
    scanf("%d", &speciesIndex);
    speciesIndex--;

    if (speciesIndex < 0 || speciesIndex >= totalSpecies) {
        printf("Invalid species index.\n");
        return;
    }

    for (i = 0; i < petInventory[speciesIndex].supplyCount; i++) {
        free(petInventory[speciesIndex].supplies[i]);
    }
    free(petInventory[speciesIndex].supplies);
    free(petInventory[speciesIndex].name);

    for ( i = speciesIndex; i < totalSpecies - 1; i++) {
        petInventory[i] = petInventory[i + 1];
    }

    totalSpecies--;
    petInventory = realloc(petInventory, totalSpecies * sizeof(struct Pet));
    printf("Species removed.\n");
}

void showInventory() {
	int i,j;
    for ( i = 0; i < totalSpecies; i++) {
        printf("\nSpecies: %s\n", petInventory[i].name);
        printf("Supplies: ");
        for ( j = 0; j < petInventory[i].supplyCount; j++) {
            printf("%s\t", petInventory[i].supplies[j]);
        }
        printf("\n");
    }
}

